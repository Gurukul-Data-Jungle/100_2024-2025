# Searches a 2D Matrix - Problem 240 on Leetcode
def searchMatrix(matrix, target):
    #Write your code here (delete the pass)
    pass